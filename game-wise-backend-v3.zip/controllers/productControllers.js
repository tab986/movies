// controllers/localProductsController.js
const mongoose = require("mongoose");
const KinguinProduct = require("../models/KinguinProduct"); // local mirror schema
const catchAsyncErrors = require("../utils/catchAsyncErrors");
const appError = require("../utils/appError");
const { convertFromIQD } = require("../utils/currency");

// controllers/localProductsController.js (excerpt)

// --- same normalizer you used in the worker ---
function normStr(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[_\-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizePlatform(p) {
  const n = normStr(p);
  if (!n) return "";

  // synonyms + regex catch-alls
  if (/(pc.*steam|steam.*pc)/.test(n)) return "pc steam";
  if (/^(uplay|ubisoft|ubisoft connect)|pc.*(uplay|ubisoft)/.test(n))
    return "pc ubisoft connect";
  if (/(origin|ea app)/.test(n)) return "ea app";
  if (/(battle\.?net|battlenet|blizzard)/.test(n)) return "pc battle.net";
  if (/epic/.test(n)) return "pc epic games";
  if (/(rockstar|social club)/.test(n)) return "pc rockstar games";
  if (/gog/.test(n)) return "pc gog";
  if (/mog station/.test(n)) return "pc mog station";
  if (n === "pc") return "pc";
  if (/^xbox series (x|s)|xbox series x\|s/.test(n)) return "xbox series x|s";
  if (/xbox one/.test(n)) return "xbox one";
  if (/xbox 360/.test(n)) return "xbox 360";
  return n;
}

function buildListQuery(qs) {
  const where = {
    "flags.hidden": { $ne: true },
    "derived.inStock": true,
  };

  const page = Math.max(1, Number(qs.page) || 1);
  const limit = Math.max(1, Math.min(200, Number(qs.limit) || 24));

  // Platform (canonical)
  if (qs.platform) {
    const canon = normalizePlatform(qs.platform);
    if (canon) where["derived.platformCanonical"] = canon;
  }
  // const wantCards = String(qs.isCard).toLowerCase() === "true";
  // where["remote.isCard"] = wantCards ? true : { $ne: true };
  // Region
  if (qs.regionId) where["remote.regionId"] = Number(qs.regionId);

  // -------- Release date (stored as "YYYY-MM-DD" string) --------
  // If you store as Date in Mongo, swap the assignments to new Date("...T00:00:00Z")
  const releaseField = "remote.releaseDate";
  const ymd = (v) => String(v).slice(0, 10); // if you're storing as "YYYY-MM-DD" strings

  if (qs.releaseDateFrom || qs.releaseDateTo || qs.releaseDate) {
    const cond = { $exists: true, $ne: null }; // exclude missing & null

    if (qs.releaseDate) {
      cond.$eq = ymd(qs.releaseDate); // exact day
    } else {
      if (qs.releaseDateFrom) cond.$gte = ymd(qs.releaseDateFrom);
      if (qs.releaseDateTo) cond.$lte = ymd(qs.releaseDateTo);
    }

    where[releaseField] = cond;
  }

  // Publishers (any-of)
  if (qs.publishers) {
    const list = String(qs.publishers)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (list.length === 1) {
      where["remote.publishers"] = list[0];
    } else if (list.length > 1) {
      where["remote.publishers"] = { $in: list };
    }
  }

  // Developers (any-of)
  if (qs.developers) {
    const list = String(qs.developers)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (list.length === 1) {
      where["remote.developers"] = list[0];
    } else if (list.length > 1) {
      where["remote.developers"] = { $in: list };
    }
  }

  // Genres
  if (qs.genres) {
    const list = String(qs.genres)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (list.length === 1) where["remote.genres"] = list[0];
    else if (list.length > 1) where["remote.genres"] = { $in: list };
  }

  // Tags (must include all)
  if (qs.tags) {
    const list = String(qs.tags)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (list.length) where["remote.tags"] = { $all: list };
  }

  // Price range
  if (qs.priceFrom || qs.priceTo) {
    const range = {};
    if (qs.priceFrom) range.$gte = Number(qs.priceFrom);
    if (qs.priceTo) range.$lte = Number(qs.priceTo);
    where["derived.priceMin"] = range;
  }
  if (qs.isAd) {
    where["overrides.isAd"] = true;
  }

  // -------- Metacritic score range --------
  // Assuming stored at remote.metacriticScore (change path if different)
  if (qs.metacriticScoreFrom || qs.metacriticScoreTo) {
    const range = {};
    if (qs.metacriticScoreFrom) range.$gte = Number(qs.metacriticScoreFrom);
    if (qs.metacriticScoreTo) range.$lte = Number(qs.metacriticScoreTo);
    where["remote.metacriticScore"] = range;
  } else if (qs.metacriticScore) {
    where["remote.metacriticScore"] = Number(qs.metacriticScore);
  }

  // Search
  if (qs.q) {
    const rx = new RegExp(String(qs.q), "i");
    where.$or = [{ "overrides.name": rx }, { "remote.name": rx }];
  }

  // -------- Sorting --------
  const sortFieldMap = {
    priceMin: "derived.priceMin",
    updatedAt: "updatedAt",
    name: ["overrides.name", "remote.name"],
    releaseDate: releaseField,
    metacriticScore: "remote.metacriticScore",
  };

  const sortByKey = [
    "priceMin",
    "updatedAt",
    "name",
    "releaseDate",
    "metacriticScore",
  ].includes(qs.sortBy)
    ? qs.sortBy
    : "priceMin";

  const dir = String(qs.sortType || "asc").toLowerCase() === "desc" ? -1 : 1;

  let sort;
  if (sortByKey === "name") {
    sort = { "overrides.name": dir, "remote.name": dir };
  } else {
    const field = sortFieldMap[sortByKey];
    sort = Array.isArray(field)
      ? { [field[0]]: dir, [field[1]]: dir }
      : { [field]: dir };
  }

  return { where, page, limit, sort };
}

const {
  lookupGameIdsByTitle,
  getPricesByGameIds,
} = require("../utils/itadClient");
// const { getShopIdsForPlatform } = require("../utils/platforms"); // if you ever need shops

exports.listProducts = catchAsyncErrors(async (req, res, next) => {
  const { where, page, limit, sort } = buildListQuery(req.query);
  const skip = (page - 1) * limit;

  let pageCount = await KinguinProduct.find(where)
    .sort(sort)
    .clone()
    .countDocuments();
  pageCount = Math.ceil(pageCount / limit);

  const [items, count] = await Promise.all([
    KinguinProduct.find(where).sort(sort).skip(skip).limit(limit).lean(),
    KinguinProduct.countDocuments(),
  ]);

  // helpers (inline)
  const truncate2 = (n) => Math.trunc(Number(n) * 100) / 100;

  const safeFormat = (amount, currency) => {
    if (amount == null) return null;
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(amount);
    } catch {
      return `${amount.toFixed(2)} ${currency}`;
    }
  };

  // before mapping, get a single FX rate for this request
  const fx1 = await convertFromIQD(req, 1); // 1 IQD → X
  const rate = fx1.fxFallback ? 1 : fx1.rate; // multiplier from IQD
  const currency = fx1.fxFallback ? "IQD" : fx1.currency; // target currency (or IQD fallback)

  const now = Date.now();
  const REFRESH_INTERVAL_MS = 48 * 60 * 60 * 1000; // 48h
  const country =
    (req.user && req.user.countryCode) ||
    process.env.ITAD_DEFAULT_COUNTRY ||
    "US";

  // ---------- Batch ITAD refresh for items on this page ----------

  // 1) pick candidates that need refresh (missing or stale officialStore)
  const candidates = items.filter((p) => {
    const os = p.officialStore;
    if (!os || !os.regularAmount || !os.lastUpdatedAt) return true;
    const age = now - new Date(os.lastUpdatedAt).getTime();
    return age > REFRESH_INTERVAL_MS;
  });

  const updatedOfficialById = {}; // _id (string) -> officialStore object

  if (candidates.length > 0) {
    // 2) build title -> [productIds] map
    const titleMap = new Map(); // key = lowercased title, value = { title, productIds: [] }

    for (const p of candidates) {
      const title =
        p.remote?.originalName || p.overrides?.name || p.remote?.name || null;
      if (!title) continue;

      const key = title.toLowerCase();
      let entry = titleMap.get(key);
      if (!entry) {
        entry = { title, productIds: [] };
        titleMap.set(key, entry);
      }
      entry.productIds.push(p._id.toString());
    }

    const titles = Array.from(titleMap.values()).map((e) => e.title);

    if (titles.length > 0) {
      try {
        // 3) lookup ITAD gameIds for all titles in one shot
        const lookupResp = await lookupGameIdsByTitle(titles);
        // lookupResp: { [title]: gameId | null }

        // 4) build gameId -> productIds map
        const gameIdToProductIds = new Map();

        for (const entry of titleMap.values()) {
          const gameId = lookupResp[entry.title];
          if (!gameId) continue;
          let arr = gameIdToProductIds.get(gameId);
          if (!arr) {
            arr = [];
            gameIdToProductIds.set(gameId, arr);
          }
          arr.push(...entry.productIds);
        }

        const gameIds = Array.from(gameIdToProductIds.keys());

        if (gameIds.length > 0) {
          // 5) fetch prices for all these gameIds in one API call
          const pricesResp = await getPricesByGameIds(gameIds, { country });

          // 6) prepare bulk Mongo updates
          const bulkOps = [];

          for (const entry of pricesResp) {
            // ✅ use `id`, not `gameId`
            const gameId = entry.id;
            const deals = entry.deals;
            if (!Array.isArray(deals) || deals.length === 0) continue;

            // choose the cheapest deal as "official reference"
            deals.sort((a, b) => a.price.amount - b.price.amount);
            const best = deals[0];

            if (!best.price || !best.regular) continue;

            // ✅ match getProduct logic: store in IQD directly (amount * 1310)
            const officialStore = {
              itadGameId: gameId,
              shopId: best.shop.id,
              shopName: best.shop.name,
              url: best.url,
              // country,      // same as you did in getProduct (commented if you want)
              // currency: best.price.currency,
              priceAmount: best.price.amount * 1310.0, // IQD
              regularAmount: best.regular.amount * 1310.0, // IQD
              cut: best.cut,
              lastUpdatedAt: new Date(),
            };

            const productIds = gameIdToProductIds.get(gameId) || [];
            for (const pid of productIds) {
              updatedOfficialById[pid] = officialStore;
              bulkOps.push({
                updateOne: {
                  filter: { _id: pid },
                  update: { $set: { officialStore } },
                },
              });
            }
          }

          if (bulkOps.length > 0) {
            await KinguinProduct.bulkWrite(bulkOps, { ordered: false });
          }
        }
      } catch (err) {
        console.error("ITAD sync in listProducts failed:", err.message);
      }
    }
  }

  // ---------- Build response with discount tags ----------

  const results = items.map((p) => {
    const priceIQD = p.derived?.priceMin ?? null;
    const priceConverted = priceIQD != null ? truncate2(priceIQD * rate) : null;

    const idStr = p._id.toString();

    // use freshly-fetched officialStore if we just updated it in this request
    let officialForResponse =
      updatedOfficialById[idStr] || p.officialStore || null;

    console.log(`updatedOfficialById ::${{ ...updatedOfficialById }}`);
    console.log(updatedOfficialById);

    // // same logic as getProduct:
    // // if our minimum IQD price is > official IQD price, hide official block
    // if (
    //   officialForResponse &&
    //   typeof priceIQD === "number" &&
    //   typeof officialForResponse.priceAmount === "number" &&
    //   priceIQD > officialForResponse.priceAmount
    // ) {
    //   officialForResponse = null;
    // }

    const discountVsOfficial = null; // keeping as-is, you commented this out in getProduct

    return {
      kinguinId: p._id,
      name: p.overrides?.name || p.remote?.name,
      images: p.remote?.images,

      // prices & currency
      currency, // e.g., 'EUR'
      priceMinIQD: priceIQD, // original in IQD (kept for debugging)
      priceMin: priceConverted, // converted, truncated to 2 decimals
      priceMinFormatted: safeFormat(priceConverted, currency),

      // ITAD / official store info for the card
      officialStore: officialForResponse
        ? {
            shopId: officialForResponse.shopId,
            shopName: officialForResponse.shopName,
            url: officialForResponse.url,
            // country: officialForResponse.country,
            // currency: officialForResponse.currency,
            priceAmount: officialForResponse.priceAmount, // already in IQD
            regularAmount: officialForResponse.regularAmount, // already in IQD
            cut: officialForResponse.cut,
            lastUpdatedAt: officialForResponse.lastUpdatedAt,
          }
        : null,

      // "Save X% vs official" – left null like in your getProduct
      // discountVsOfficial,

      inStock: p.derived?.inStock,
      regionId: p.remote?.regionId,
      regionalLimitations: p.remote?.regionalLimitations,
      countryLimitation: p.remote?.countryLimitation,
      tags: p.remote?.tags,
      platform: p.remote?.platform,
      qty: p.remote?.qty,
      updatedAt: p.remote?.updatedAt,
      activationDetails: p.remote?.activationDetails,
      videos: p.remote?.videos,
      languages: p.remote?.languages,
      systemRequirements: p.remote?.systemRequirements,
      originalName: p.remote?.originalName,
      metacriticScore: p.remote?.metacriticScore,
      genres: p.remote?.genres,
      publishers: p.remote?.publishers,
      developers: p.remote?.developers,
      releaseDate: p.remote?.releaseDate,
      description: p.overrides?.description || p.remote?.description,
      remote: p.remote, // keep for admin/debug
    };
  });

  res.status(200).json({
    status: "success",
    meta: { pageCount, page, limit, item_count: count },
    results,
  });
});

const { getOfficialDealForTitle } = require("../utils/itadClient");
const { getShopIdsForPlatform } = require("../utils/platforms");

exports.getProduct = catchAsyncErrors(async (req, res, next) => {
  const kinguinId = Number(req.params.kinguinId);
  if (!kinguinId) return next(new appError("kinguinId must be a number", 400));

  // Lean for perf
  let p = await KinguinProduct.findById(kinguinId).lean();
  if (!p || p.flags?.hidden === true) {
    return res.status(404).json({ status: "not_found" });
  }

  const truncate2 = (n) => Math.trunc(Number(n) * 100) / 100;

  // FX for our own price (IQD → user currency)
  const fx = await convertFromIQD(req, 1);
  const rate = fx.fxFallback ? 1 : fx.rate;
  const currency = fx.fxFallback ? "IQD" : fx.currency;

  const priceIQD = p.derived?.priceMin ?? null;
  const priceConverted = priceIQD != null ? truncate2(priceIQD * rate) : null;

  // ---------- Official/original price (ITAD) with 24h cache ----------

  const now = Date.now();
  const TWENTY_FOUR_HOURS = 48 * 60 * 60 * 1000;

  let officialStore = p.officialStore || null;

  const needsRefresh =
    !officialStore ||
    !officialStore.regularAmount ||
    !officialStore.lastUpdatedAt ||
    now - new Date(officialStore.lastUpdatedAt).getTime() > TWENTY_FOUR_HOURS;

  if (needsRefresh) {
    const title = p.remote?.originalName;

    const shopIds = getShopIdsForPlatform(p.remote?.platform);
    const country =
      (req.user && req.user.countryCode) ||
      process.env.ITAD_DEFAULT_COUNTRY ||
      "US";
    let newp;
    try {
      const deal = await getOfficialDealForTitle(title, {
        country,
        shopIds,
      });

      if (deal) {
        officialStore = {
          itadGameId: deal.itadGameId,
          shopId: deal.shopId,
          shopName: deal.shopName,
          url: deal.url,
          // country: deal.country,
          // currency: deal.currency,
          priceAmount: deal.priceAmount * 1310.0,
          regularAmount: deal.regularAmount * 1310.0,
          cut: deal.cut,
          lastUpdatedAt: new Date(),
        };

        // Update Mongo separately (p is lean)
        newp = await KinguinProduct.findByIdAndUpdate(
          kinguinId,
          { officialStore },
          { new: false }
        );
      }
    } catch (e) {
      console.error("ITAD price fetch failed", {
        kinguinId,
        error: e.message,
      });
    }
  }

  // ---------- Discount tag for the card ----------

  let discountVsOfficial = null;

  // We only compute when currencies match; otherwise leave null
  // if (
  //   officialStore &&
  //   typeof priceConverted === "number" &&
  //   typeof officialStore.regularAmount === "number" &&
  //   officialStore.regularAmount > 0 &&
  //   officialStore.currency === currency
  // ) {
  //   const ratio = 1 - priceConverted / officialStore.regularAmount;
  //   discountVsOfficial = Math.max(0, Math.round(ratio * 100));
  // }
  if (officialStore && priceIQD > officialStore?.priceAmount)
    officialStore = null;

  res.status(200).json({
    status: "success",
    data: {
      kinguinId: p._id,
      name: p.overrides?.name || p.remote?.name,
      description: p.overrides?.description || p.remote?.description,
      images: p.overrides?.images || p.remote?.images,

      // our store price
      currency,
      priceMinIQD: priceIQD,
      priceMin: priceConverted,

      inStock: p.derived?.inStock,
      regionId: p.remote?.regionId,
      platform: p.remote?.platform,
      regionalLimitations: p.remote?.regionalLimitations,
      countryLimitation: p.remote?.countryLimitation,
      qty: p.remote?.qty,
      updatedAt: p.remote?.updatedAt,
      activationDetails: p.remote?.activationDetails,
      videos: p.remote?.videos,
      languages: p.remote?.languages,
      systemRequirements: p.remote?.systemRequirements,
      originalName: p.remote?.originalName,
      metacriticScore: p.remote?.metacriticScore,
      genres: p.remote?.genres,
      publishers: p.remote?.publishers,
      developers: p.remote?.developers,
      releaseDate: p.remote?.releaseDate,
      tags: p.remote?.tags,

      // ITAD / official store info
      officialStore: officialStore
        ? {
            shopId: officialStore.shopId,
            shopName: officialStore.shopName,
            url: officialStore.url,
            country: officialStore.country,
            currency: officialStore.currency,
            priceAmount: officialStore.priceAmount,
            regularAmount: officialStore.regularAmount,
            cut: officialStore.cut, // store’s own discount vs its regular price
            lastUpdatedAt: officialStore.lastUpdatedAt,
          }
        : null,

      // // discount tag you can slap on the card:
      // // "Save X% vs official" — this is OUR price vs official regular price.
      // discountVsOfficial,

      remote: p.remote,
    },
  });
});

exports.patchOverrides = catchAsyncErrors(async (req, res, next) => {
  const id = Number(req.params.kinguinId);
  if (!id) return next(new appError("kinguinId must be a number", 400));

  const allowed = {};
  if (req.body?.name !== undefined)
    allowed["overrides.name"] = String(req.body.name);
  if (req.body?.name !== undefined)
    allowed["overrides.isAd"] = String(req.body.isAd);
  if (req.body?.description !== undefined)
    allowed["overrides.description"] = String(req.body.description);
  if (req.body?.images !== undefined)
    allowed["overrides.images"] = req.body.images;
  if (req.body?.coverImage !== undefined)
    allowed["overrides.images"] = req.body.images;
  if (!Object.keys(allowed).length)
    return next(new appError("No override fields provided", 400));

  const updated = await KinguinProduct.findOneAndUpdate(
    { _id: id },
    { $set: allowed },
    { new: true, upsert: true }
  ).lean();

  res.status(200).json({
    status: "success",
    data: {
      kinguinId: updated._id,
      name: updated.overrides?.name || updated.remote?.name,
      images: updated.overrides?.images || updated.remote?.images,
      description:
        updated.overrides?.description || updated.remote?.description,
    },
  });
});
